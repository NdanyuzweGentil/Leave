<?php

 $leave_types = ['annual'=>"Annual Leave",'sick'=>"Sick Leave",'maternity'=>'Maternity Leave',
        'paternity'=>'Paternity Leave','study'=>'Study Leave','emergency'=>'Emergency Leave',
        'casual'=>'Casual Leave','special'=>'Special Leave','examinations'=>'Exams Leave',
        'sports'=>'Sports Leave','absense'=>'Absence Leave',
        'short_embark_disembark'=>'Short Embarkation/Disembarkation Leave',
        'long_embark_disembark'=>'Long Embarkation/Disembarkation Leave'];
 
 $arr = ['annual','sick','maternity','paternity','study','emergency','casual','special',
         'examinations','sports','absense','short_embark_disembark','long_embark_disembark'];